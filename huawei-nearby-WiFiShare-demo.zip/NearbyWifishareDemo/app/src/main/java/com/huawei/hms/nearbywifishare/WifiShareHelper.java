package com.huawei.hms.nearbywifishare;

import android.content.Context;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import com.huawei.hms.nearby.Nearby;
import com.huawei.hms.nearby.discovery.ScanEndpointInfo;
import com.huawei.hms.nearby.wifishare.WifiShareCallback;
import com.huawei.hms.nearby.wifishare.WifiShareEngine;
import com.huawei.hms.nearby.wifishare.WifiSharePolicy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class WiFiShareHelper {
    private static final String TAG = "Wi-FiShareDemo*Helper";
    private Context mContext;
    private HashMap<String, ScanEndpointInfo> mScanEndpointMap;
    private ListView mNearbyDevicesListView;
    private TextView mAuthCodeTextView;
    private WifiShareEngine mWiFiShareEngine;

    public WiFiShareHelper(Context context) {
        mContext = context;
        mWiFiShareEngine = Nearby.getWifiShareEngine(context);
        mScanEndpointMap = new HashMap<>();
    }

    private WifiShareCallback mWiFiShareCallback = new WifiShareCallback() {
        @Override
        public void onFound(String endpointId, ScanEndpointInfo scanEndpointInfo) {
            Log.e(TAG, "onFound");
            mScanEndpointMap.put(endpointId, scanEndpointInfo);
            showListView();
        }

        @Override
        public void onLost(String endpointId) {
            Log.e(TAG, "onLost");
            mScanEndpointMap.remove(endpointId);
            showListView();
        }

        @Override
        public void onFetchAuthCode(String endpointId, String authCode) {
            Log.e(TAG, "onFetchAuthCode: " + authCode);
            // To display AuthCode
            String toDisplay = mContext.getString(R.string.auth_code) + authCode;
            mAuthCodeTextView.setText(toDisplay);
        }

        @Override
        public void onWifiShareResult(String endpointId, int statusCode) {
            mWiFiShareEngine.stopWifiShare();
            Log.e(TAG, "WiFiShare result: " + endpointId + ", statusCode: " + statusCode);
        }
    };

    // The device to share WiFi
    public void shareWiFiConfig() {
        Log.d(TAG, "Start to share WiFi");
        mWiFiShareEngine.startWifiShare(mWiFiShareCallback, WifiSharePolicy.POLICY_SHARE)
                .addOnFailureListener(
                        e -> Log.e(TAG, Objects.requireNonNull(e.getMessage())));
        showListView();
        setListViewListenerMode();
    }

    // The device to connect WiFi
    public void requestWiFiConfig() {
        Log.d(TAG, "requestWiFiConfig");
        mWiFiShareEngine.startWifiShare(mWiFiShareCallback, WifiSharePolicy.POLICY_SET)
                .addOnFailureListener(
                        e -> Log.e(TAG, Objects.requireNonNull(e.getMessage())));
    }
    
    public void setViewToFill(ListView listView, TextView textView) {
        mNearbyDevicesListView = listView;
        mAuthCodeTextView = textView;
    }

    // To show onFound devices, and select a device to share WiFi
    private void showListView() {
        List<HashMap<String, Object>> data = new ArrayList<>();
        for (Map.Entry<String, ScanEndpointInfo> entry: mScanEndpointMap.entrySet()) {
            HashMap<String, Object> item = new HashMap<>();
            item.put("id", entry.getKey());
            item.put("name", entry.getValue().getName());
            data.add(item);
        }
        SimpleAdapter mSimpleAdapter = new SimpleAdapter(mContext, data, R.layout.item,
                new String[]{"id", "name"}, new int[]{R.id.itemId, R.id.itemName});
        mNearbyDevicesListView.setAdapter(mSimpleAdapter);
    }

    private void setListViewListenerMode() {
        mNearbyDevicesListView.setOnItemClickListener((parent, view, position, id) -> {
            Log.d(TAG, "ListView on click listener");
            HashMap<String, Object> item = (HashMap<String, Object>) mNearbyDevicesListView.getItemAtPosition(position);
            String endpointId = (String) item.get("id");
            Log.e(TAG, "Share WiFi to endpoint: " + endpointId);
            mWiFiShareEngine.shareWifiConfig(endpointId);
        });
    }
}
